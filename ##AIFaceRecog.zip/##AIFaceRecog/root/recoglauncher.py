import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent

python = sys.executable

subprocess.Popen([python, str(BASE_DIR / "RealtimeRecognitionAndRecording.py")])
subprocess.Popen([python, str(BASE_DIR / "DBStatUI.py")])
