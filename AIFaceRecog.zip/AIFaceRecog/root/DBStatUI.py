import sqlite3
import tkinter as tk
from tkinter import ttk
from pathlib import Path

# -------------------- Paths (portable) --------------------
BASE_DIR = Path(__file__).resolve().parent.parent   # ##AIFaceRecog/
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "primaryrec.db"

REFRESH_INTERVAL = 2000  # milliseconds


class AttendanceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Real-Time Attendance Dashboard")
        self.root.geometry("600x400")

        self.tree = ttk.Treeview(
            root,
            columns=("id", "status", "time"),
            show="headings"
        )

        self.tree.heading("id", text="Student ID")
        self.tree.heading("status", text="Status")
        self.tree.heading("time", text="Last Event Time")

        self.tree.column("id", width=100, anchor="center")
        self.tree.column("status", width=120, anchor="center")
        self.tree.column("time", width=220, anchor="center")

        self.tree.pack(fill=tk.BOTH, expand=True)

        self.refresh()

    def refresh(self):
        # Clear old rows
        for row in self.tree.get_children():
            self.tree.delete(row)

        if not DB_PATH.exists():
            self.root.after(REFRESH_INTERVAL, self.refresh)
            return

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT student_id, COUNT(*) AS cnt, MAX(timestamp)
            FROM attendance
            GROUP BY student_id
        """)

        for student_id, cnt, last_time in cursor.fetchall():
            status = "Present" if cnt % 2 == 1 else "Not Present"
            self.tree.insert(
                "",
                tk.END,
                values=(student_id, status, last_time)
            )

        conn.close()

        # Schedule next refresh
        self.root.after(REFRESH_INTERVAL, self.refresh)


if __name__ == "__main__":
    root = tk.Tk()
    AttendanceApp(root)
    root.mainloop()
