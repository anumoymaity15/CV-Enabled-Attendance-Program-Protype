import subprocess
import sys
from pathlib import Path

# Base directory: ##AIFaceRecog/root
BASE_DIR = Path(__file__).resolve().parent

PYTHON = sys.executable

# Launch real-time recognition + DB dashboard together
subprocess.Popen([PYTHON, str(BASE_DIR / "realtime_recog_statupdate_core.py")])
subprocess.Popen([PYTHON, str(BASE_DIR / "DBStatUI.py")])
