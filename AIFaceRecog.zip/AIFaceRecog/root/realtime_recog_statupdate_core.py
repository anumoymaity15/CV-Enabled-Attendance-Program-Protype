import cv2
import sqlite3
import time
from pathlib import Path
from collections import defaultdict

# ---------------- PATHS (portable) ----------------
BASE_DIR = Path(__file__).resolve().parent.parent   # ##AIFaceRecog/
DATA_DIR = BASE_DIR / "data"
RECOGNIZER_PATH = DATA_DIR / "recognizer.yml"
DB_PATH = DATA_DIR / "primaryrec.db"

# ---------------- CONSTANTS ----------------
FACE_SIZE = (200, 200)
EVENT_INTERVAL = 120  # seconds (2 minutes)

# ---------------- DATABASE ----------------
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS attendance (
    student_id INTEGER,
    timestamp TEXT
)
""")
conn.commit()

# ---------------- LOAD MODELS ----------------
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read(str(RECOGNIZER_PATH))

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

# ---------------- CAMERA ----------------
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Camera not detected")
    exit()

# ---------------- STATE ----------------
last_event_time = {}                 # student_id → last DB write time
presence_count = defaultdict(int)    # student_id → entry/exit counter

print("Starting real-time recognition. Press Q to exit.")

# ================= MAIN LOOP =================
while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        face = gray[y:y+h, x:x+w]
        face = cv2.resize(face, FACE_SIZE)

        student_id, confidence = recognizer.predict(face)
        now = time.time()
        status = None

        # -------- EVENT-BASED LOGIC --------
        if student_id not in last_event_time:
            last_event_time[student_id] = now
            presence_count[student_id] += 1
            status = "Present"

        elif now - last_event_time[student_id] >= EVENT_INTERVAL:
            last_event_time[student_id] = now
            presence_count[student_id] += 1
            status = (
                "Present"
                if presence_count[student_id] % 2 == 1
                else "Not Present"
            )

        # -------- DATABASE WRITE (EVENT ONLY) --------
        if status is not None:
            cursor.execute(
                "INSERT INTO attendance (student_id, timestamp) VALUES (?, ?)",
                (
                    student_id,
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now))
                )
            )
            conn.commit()
            print(f"Student {student_id} → {status}")

        # -------- VISUAL FEEDBACK --------
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(
            frame,
            f"ID:{student_id}",
            (x, y-10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            (0, 255, 0),
            2
        )

    cv2.imshow("Recognition - Press Q to exit", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# ---------------- CLEANUP ----------------
cap.release()
cv2.destroyAllWindows()
conn.close()
print("Realtime recognition stopped")
