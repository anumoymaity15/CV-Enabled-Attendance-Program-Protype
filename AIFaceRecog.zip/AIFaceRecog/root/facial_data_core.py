import cv2
import os
import time
import numpy as np

from pathlib import Path

# Paths
DATA_DIR = Path(r"D:\_TheLostFolder_\##AIFaceRecog\data")
FACES_DIR = DATA_DIR / "faces"
RECOGNIZER_PATH = DATA_DIR / "recognizer.yml"

# Constants
FACE_SIZE = (200, 200)
MAX_IMAGES = 30
CAPTURE_INTERVAL = 0.3  # seconds between captures

# Initialize face detector
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

# Start webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Camera not detected")
    exit()

# Input student ID
person_id = input("Enter numeric ID for this person: ")
save_path = FACES_DIR / str(person_id)
os.makedirs(save_path, exist_ok=True)
print(f"Saving faces to: {save_path}")

# Capture loop
count = 0
last_capture = time.time()
while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        now = time.time()
        if now - last_capture >= CAPTURE_INTERVAL and count < MAX_IMAGES:
            count += 1
            face_img = gray[y:y+h, x:x+w]
            face_img = cv2.equalizeHist(face_img)
            face_img = cv2.resize(face_img, FACE_SIZE)
            cv2.imwrite(str(save_path / f"{count}.jpg"), face_img)
            last_capture = now
            print(f"Captured image {count}/{MAX_IMAGES}")

        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

    cv2.imshow("Registering Face - Press Q to stop", frame)

    if cv2.waitKey(1) & 0xFF == ord('q') or count >= MAX_IMAGES:
        break

cap.release()
cv2.destroyAllWindows()
print("Face registration complete")

# Training LBPH recognizer
print("Training recognizer...")
faces_list = []
labels_list = []

for person_folder in FACES_DIR.iterdir():
    if not person_folder.is_dir():
        continue
    for img_file in person_folder.iterdir():
        img = cv2.imread(str(img_file), cv2.IMREAD_GRAYSCALE)
        if img is not None:
            faces_list.append(img)
            labels_list.append(int(person_folder.name))

faces_np = np.array(faces_list)
labels_np = np.array(labels_list)

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.train(faces_np, labels_np)
recognizer.save(str(RECOGNIZER_PATH))
print(f"Training complete. Recognizer saved at {RECOGNIZER_PATH}")
