Smart Attendance System - Instructions

****   RUN "lib_installer.bat" TO INSTALL NECESSARY LIBRARIES AND COMPONENTS   ****

Folder structure:
- data/
    - faces/           : captured face images per student
    - primaryrec.db    : SQLite database for attendance
    - recognizer.yml   : trained LBPH recognizer
- root/
    - facial_data_core.py                  : capture faces & train model
    - realtime_recog_statupdate_core.py    : run real-time recognition & update DB
    - DBStatUI.py                          : live attendance dashboard
    - recoglauncher.py                     : launcher for recognition + dashboard
    - acqlauncher.bat                    : launcher for facial data capture & training

Instructions:
1. Register students:
   - Double-click or run acqlauncher.bat
   - Enter numeric ID
   - Capture 30 images per student
   - Training happens automatically after capture

2. Run recognition:
   - Double-click or run recoglauncher.py
   - Camera feed opens
   - Attendance is recorded in primaryrec.db automatically

3. View real-time attendance:
   - Dashboard (DBStatUI.py) shows current Present/Not Present status
   - Updates every 2 seconds

Requirements:
- Python 3.12
- pip-installed libraries:
  - opencv-python, opencv-contrib-python
  - numpy
  - imutils
  - sqlite3 (built-in)
  - Tkinter (built-in)

Notes:
- No exe required; scripts can be run directly
- Make sure the camera is connected and accessible